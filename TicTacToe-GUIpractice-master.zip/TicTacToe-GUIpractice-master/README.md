# TicTacToe-GUIpractice
First attempts at using pygame displayed through a simple game of tictactoe. This is my first attempt at using GUI's so it's been kept very simple. Unfinished.

## Author

* **Samantha Kyle** *

## Future Additions

I plan to expand upon this project as I become more comfortable with GUI's and user interaction as a whole.
The end goal of this project will include:
 - 2 player mode
 - Easy mode and Hard mode (AI guesses randomly vs. AI has strategy)
 - Replayability
 - Timer on screen
